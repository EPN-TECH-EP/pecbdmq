import { Directive } from '@angular/core';

@Directive({
  selector: '[mdbDropdownToggle]',
  exportAs: 'mdbDropdownToggle',
})
export class MdbDropdownToggleDirective {
  constructor() {}
}
