export { MdbLazyLoadingDirective } from './lazy-loading.directive';
export { MdbLazyLoadingModule } from './lazy-loading.module';
