export { MdbCollapseDirective } from './collapse.directive';
export { MdbCollapseModule } from './collapse.module';
