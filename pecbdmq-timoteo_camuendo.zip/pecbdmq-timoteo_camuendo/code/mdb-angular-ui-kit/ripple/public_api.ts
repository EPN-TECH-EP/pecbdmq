export { MdbRippleDirective } from './ripple.directive';
export { MdbRippleModule } from './ripple.module';
