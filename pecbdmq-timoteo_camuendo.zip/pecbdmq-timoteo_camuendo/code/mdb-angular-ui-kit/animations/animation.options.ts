export interface MdbAnimationOptions {
  trigger?: string;
  delay?: number;
  duration?: number;
}
