export { MdbLoadingComponent } from './loading.component';
export { MdbLoadingModule } from './loading.module';
