import { MdbOptionComponent } from '../option/option.component';

export interface ISelectedOption {
  text: string;
  element: MdbOptionComponent;
}
