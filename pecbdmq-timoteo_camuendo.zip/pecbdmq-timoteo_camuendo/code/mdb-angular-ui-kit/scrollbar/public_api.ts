export { MdbScrollbarDirective } from './scroll.directive';
export { MdbScrollbarModule } from './scroll.module';
