export { MdbCarouselComponent } from './carousel.component';
export { MdbCarouselItemComponent } from './carousel-item.component';
export { MdbCarouselModule } from './carousel.module';
